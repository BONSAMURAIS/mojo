# Project name

Basic project description

Badges in Markdown format:

* For readthedocs, click on the info button next to the badge in https://readthedocs.org/projects/whatever/, and copy the markdown code
* For travis, click on the badge in https://travis-ci.org/BONSAMURAIS/whatever, and copy the markdown code
* For appveyor, go to the projects settings page, and then click on "badges", and copy the markdown code

## Installation

Details on how to install the package

## Contributing

Details on how to contribute
